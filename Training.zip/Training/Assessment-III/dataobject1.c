//1. reading data objects from keyboard and forming doubly-linked list 
//#pragma startup app_init
//#pragma exit app_close
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Book_t
{
	int bookid;
	char title[16];
	char author[32];
	char publication[64];
	int numberOfCopies;
	int price;
};
typedef struct Book_t Book1;


typedef struct _Node_t
{
	struct _Node_t *prev;
	Book1 data;
	struct _Node_t *next;
}Node_t;

Node_t *head = NULL;
Node_t *tail = NULL;

void insertNodeBack(Book1);
Node_t * createNode(Book1);
void readDetails(Book1*);
void doTraversal_for_DB();
void db_book_read(int count);
void doTraversal_to_write();
void printDetails(Book1);
void clear_input_buffer();
void destroy();
void deleteNodeFront();
void __attribute__((constructor))app_init()
{
#if DEBUG==1
	printf("Inside app_init\n");
#endif
}

void __attribute__((destructor))app_close()
{
    destroy();
#if DEBUG==1
	printf("Inside app_close\n");
	printf("alloc = %d",alloc_count);
	printf("dealloc = %d",dealloc_count);
#endif
} 
int main()
{
    //app_init();
	Book1 book = {};
	int n;
	printf("\n Enter book details number:");
	scanf("%d",&n);
	//clear_input_buffer();
	
	
	for ( int I = 0; I<n; I++)
	{
		readDetails(&book);
		insertNodeBack(book);
		
	}
	#if DEBUG==1
	printf("Calling doTraversal_for_DB\n");
	#endif
    doTraversal_for_DB();
    #if DEBUG==1
    printf("End calling doTraversal_for_DB\n");
    #endif
	destroy();
	#if DEBUG==1
	printf("Calling db_book_read\n");
	#endif
	db_book_read(n);
	#if DEBUG==1
		printf("End calling db_book_read\n");
		
	printf("Calling doTraversal_to_write\n");
	#endif
 	doTraversal_to_write();
 	#if DEBUG==1
 	printf("End Calling doTraversal_to_write\n");
 	#endif
	
	
    
    //app_close();
    return 0;
}

Node_t * createNode(Book1 book)
{
   Node_t *node = (Node_t *)malloc(1*sizeof(Node_t)); // (Node_t *)calloc(1,sizeof(Node_t))
   memset(node,0,sizeof(Node_t));
   node->data = book;   //memcpy(&node->data, &val, sizeof(BankCustomer_t)) //shallow copy
   node->prev = NULL;
   node->next = NULL;
   
   return node;
}
void insertNodeBack(Book1 book)
{
	Node_t* node = createNode(book);
	
	if( head == NULL )
	{
		head = tail = node;
		
	}
    else
	{
	   tail->next = node;
	   node->prev = tail;
	   tail = node;
	}
}

void readDetails(Book1* book)
{
	    printf("Enter book id:");
    	
    	scanf("%d",&book->bookid);
    	printf("\n");
    	printf("Enter book title:");
    	clear_input_buffer();
    	
    	scanf("%s", book->title);
    	printf("\n");
    	printf("Enter book author:");
    	clear_input_buffer();
    	scanf("%s",book->author);
    	printf("\n");
    	printf("Enter book publication:");
    	clear_input_buffer();
    	
    	scanf("%s", book->publication);
    	printf("\n");
    	printf("Enter number of copies:");
    	clear_input_buffer();
    	
    	scanf("%d", &book->numberOfCopies);
    	printf("\n");
    	printf("Enter price:");
    	clear_input_buffer();
    	
    	scanf("%d", &book->price);
    	printf("\n");
   }
    	

void db_book_add(Book1* bookaddr)
{
  char filename [] = "book.dat";
  FILE* out = fopen(filename, "ab");
  if(out == NULL)
  {
     printf("FILE ERROR");
  }
  else
  {
    fwrite(bookaddr, sizeof(Book1), 1, out);
  }
  fclose(out); 
}

void doTraversal_for_DB()
{
	Node_t *node = head;
	
	if( node == NULL )
	{
	    printf("\n\n Book List is Empty ....\n");
	}
    else
	{
	    do
		{
			//printDetails(node->data);
			db_book_add(&node->data);
			node = node->next;
        }while(node != NULL);
	}	
}

void printDetails(Book1 val)
{
   printf("\n\n\n\n");
   printf("\tBookid : %d\n",val.bookid);
   printf("\tBook Title : %s\n",val.title);
   printf("\tBook author : %s\n",val.author);
   printf("\tBook Publication : %s\n",val.publication);
   printf("\tBook numberOfCopies : %d\n",val.numberOfCopies);
   printf("\tBook Price : %d\n",val.price);
}

void clear_input_buffer()
{
	while(getchar() != '\n');
}

void destroy()
{
	
	if( head == NULL )
	{
	    //printf("\n\n Customer List is Empty ....\n");
	}
    else
	{
	    do
		{
			deleteNodeFront();
        }while(head != NULL);
	}	
}

void deleteNodeFront()
{
   Node_t* node = head;
   if(head->next != NULL)
   {
      head->next->prev = NULL;
      head = head->next;
   }
   else
   {
   	  head = tail = NULL; 	  
   } 
   printDetails(node->data);
   node->next = NULL;
   free(node);  
}
void db_book_read(int count){
	char filename [] = "book.dat";
	Book1 temp;
	FILE* in = fopen(filename,"rb");
	if(in==NULL){
	printf("File Error..!");
	return;
	}
	while(fread(&temp,1,sizeof(Book1),in)){
	
	 insertNodeBack(temp); 
	 }
	 fclose(in);

}
void doTraversal_to_write()
{
	Node_t *node = head;
	
	if( node == NULL )
	{
	    printf("\n\n Book List is Empty ....\n");
	}
    else
	{
	    do
		{
			printDetails(node->data);
			//db_bank_add(&node->data);
			node = node->next;
        }while(node != NULL);
	}	
}

   		







