#include<stdio.h>
#include<string.h>

union measure
{
	int number;
	float litre;
	double gram;
};

struct product
{
	int code;
	char name[151];
	double price;
	union measure stock;
	char uom;
};

void show(struct product p);

int main()
{
	struct product p1, p2;

	p1.code = 5;
	strcpy(p1.name, "Pen");
	p1.price = 20.00;
	p1.stock.number = 3;
	p1.uom = 'N';

	p2.code = 10;
	strcpy(p2.name, "Sugar");
	p2.price = 55.00;
	p2.stock.gram = 3000;
	p2.uom= 'G';

	union measure m1, m2;

	m1.number = 22;
	m2.litre = 4.5F;

	show(p1);
	show(p2);

	show(p1);
	show(p2);

	return 0;
}

void show(struct product p)
{
	printf("Code : %d, Name : '%s', Price : %lg, Stock : ", p.code, p.name, p.price);
	switch(p.uom)
	{
		case 'N':
		case 'n':
			printf("%d nos", p.stock.number);
			break;
		case 'G':
			printf("%lg gms", p.stock.gram);
			break;
		case 'L':
			printf("%lg ltr", p.stock.litre);
			break;
		default:
			printf("Unknown");
	}
	printf("\n");
	
	/*p.code = 0;
	strcpy(p.name, "");
	p.price = 0;
	
	printf("****Code : %d, Name : '%s', Price : %lg, Stock : ***\n", p.code, p.name, p.price);*/
}
