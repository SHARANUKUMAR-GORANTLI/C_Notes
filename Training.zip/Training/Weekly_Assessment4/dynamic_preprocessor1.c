#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define DO_SORT_YES 1
typedef struct num     //struct num1
{
	int N;
	struct num* next;
}
num1;
void print(num1*);
void linked_list(int *ptr, int count)
{
  num1* head = NULL,*temp,*temp1;
  while(count)
  {
      temp = (num1*)malloc(sizeof(num1));
      temp->N = *ptr;
      ptr++;
      if(head == NULL)
      {
      	temp->next = head;
      	head = temp;
      }
      else
      {
      	temp1 = head;
      	while(temp1->next)
      		temp1 = temp1->next;
      	temp1->next = temp;
      	temp->next = NULL;
      }	
      count--;
  }    
  print(head); 
}
void print(num1* temp)
{
   while(temp)
   {
   		printf("%d ",temp->N);
   		temp = temp->next;
   }
   printf("\n");			
}
int main()
{
	int number,count=0;
	printf("Enter the Number : ");
	scanf("%d",&number);
	int *p = (int *)malloc(number* sizeof(int));  //dynamic array
	printf("Enter the elements in array :");
	for(int i = 0; i<number; i++)
	{
		scanf("%d",&p[i]);
	}
	for(int i=0; i<number-1; i++)
	{
		for(int j = i+1; j<number; j++)
		{
		    if ((p[i]!=0) && (p[i] == p[j]))
		    {
		        p[j]=0;
		        count++;
		    }    
		}
	}
	printf("count = %d\n",count);
	int *q=(int*)malloc((number-count)*sizeof(int));
	for( int i=0, j=0; i<number; i++)
	{
		if(p[i] != 0)
		{
			q[j] = p[i];
			j++;
		}
	}

	#if defined(DO_SORT_YES) && DO_SORT_YES==1
	for(int i = 0; i<(number-count)-1; i++)
	{
	   for(int j = i+1; j<(number-count); j++)
	   {
	      int temp;
	      if(q[i] > q[j])
	      {
	         temp = q[i];
	         q[i] = q[j];
	         q[j] = temp;
	      }
	    }
	}
	printf(" sorted elements : ");      
    linked_list(q,number-count);
   #else
    printf(" non-sorted elements : ");
    linked_list(q,number-count);
   #endif
   for(int i = 0; i < (number - count); i++)
   {
   		printf("%d", q[i]);	
   	}
   	printf("\n");
   	
	free(p);
	free(q);
	p=NULL;
	q=NULL;
}

