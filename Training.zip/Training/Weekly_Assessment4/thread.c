#include<stdio.h>
#include<threads.h>
#include<stdlib.h>
#include<time.h>
#include<stdatomic.h>
#define MAX_COUNTER 10000000
long counter = 0;
atomic_long counter1 = 0;
clock_t t1,t2;
void doCount()
{
	 printf("docount");
	for(int i = 0; i < MAX_COUNTER; i++)
	{
	     printf("race condition");
		counter += 1;    /***RACE***/
	}
}
int doCount_routine()
{
	doCount();
	return 0;
}	
void process()
{
	printf("process:");
	thrd_t th1, th2;
	thrd_create(&th1, doCount_routine,NULL);
	thrd_create(&th2,doCount_routine,NULL);
	thrd_join(th1,NULL);
	thrd_join(th2,NULL);  //concurrency exit
	printf("concurrency exit/simultaneous exit");
	printf("\n count = %ld ", counter);
}
void doCount1()
{
	for(int i=0; i < MAX_COUNTER; i++)
	{
		counter1 += 1;
	}
}
int doCount1_routine()
{
	doCount1();
	return 0;	
}
void process1()
{
    printf("process1");
	thrd_t th3, th4;
	thrd_create(&th3,doCount1_routine,NULL);
	thrd_create(&th4,doCount1_routine,NULL);
	thrd_join(th3,NULL);
	thrd_join(th4,NULL);
	printf("\n count = %ld", counter1);
}
void doCount2()
{
	long counterTemp = 0;
	for(int i = 0; i < MAX_COUNTER; i++)
	{
		counterTemp += 1;
	}
	counter1 += counterTemp;	
}
int doCount2_routine()
{
	doCount2();
	return 0;
}

void process2()
{
     printf("process2");
	thrd_t th5, th6;
	thrd_create(&th5,doCount2_routine,NULL);
	thrd_create(&th6,doCount2_routine,NULL);
	thrd_join(th5,NULL);
	thrd_join(th6,NULL);
	printf("\n count = %ld", counter1);
}



int main()
{
	printf("Entering to the main function");
	int n=5;
	printf("without lock\n");
	while(n)
	{
	    printf("Inside while loop/without lock");
		counter = 0;
		t1 = clock();
		process();
		t2=clock();
		double dur = 1000.0 *(t2-t1)/CLOCKS_PER_SEC;
		printf("CPU time used(per clock()):%.2f ms\n", dur);
		n--;
	}
	n = 5;
	printf("\n with atomic lock \n");
	while(n)
	{
	printf("Inside while loop/atomic lock");
		counter1 = 0;
		t1 = clock();
		process1();
		t2 = clock();
		double dur = 1000.0 *(t2-t1)/CLOCKS_PER_SEC;
		printf("CPU time used (per clock()):%.2f ms\n", dur);
		//disp_time();
		n--;
	}
	n=5;
	printf("\n with atomic lock with reduced time\n");
	while(n)
	{
		counter1 = 0;
		t1 = clock();
		process2();
		t2 = clock();
		double dur = 1000.0 *(t2-t1)/CLOCKS_PER_SEC;
		printf("CPU time used (per clock()):%.2f ms\n", dur);
		//disp_time();
		n--;
	}
	return 0;
}
