#include<stdio.h>
#include<stdlib.h>
int main()
{
	int * nums = (int*)malloc(sizeof(int)*3);
	printf("\n Enter the 3 numbers\n");
	for(int i=0; i<3; i++)
	scanf("%d",&nums[i]);
	printf("\n Enter numbers are \n");
	for(int i=0; i<3;i++)
	printf("%d\n",nums[i]);
	free(nums);
	nums = NULL;
	return 0;
}
