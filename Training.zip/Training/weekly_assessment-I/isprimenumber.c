#define TRUE 1
#define FALSE 0
#include<stdio.h>
#include<stdlib.h>
int isprimenumber(int N);
int main()
{
   int NA,NB;
   printf("Enter a Number N1:");
   scanf("%d",&NA);

   printf("Enter a Number N22:");
   scanf("%d",&NB);
  if(isprimenumber(NA)) 
  {
     printf("%d is prime number\n",NA);
  }
  else
  {
     printf("%d is not a prime number\n",NA);
     return EXIT_FAILURE;
  }

  if(isprimenumber(NB)) 
  {
     printf("%d is prime number\n",NB);
  }
  else
  {
     printf("%d is not a prime number\n",NB);

     return EXIT_FAILURE;
  }
printf("sum is =%d",(NA+NB)); 
return EXIT_SUCCESS;
}
int isprimenumber(int N)   //N=5
{
    int isprime=TRUE;
    for(int middlenumber=2;middlenumber<N;middlenumber++)
    {

         if(N%middlenumber==0)
         {
              isprime=FALSE; 
               break; 
            }

   }
return isprime;

}

------------------------------------------------
compilation and Build
 gcc isprimenumber.c -c
 gcc isprimenumber.o -o isprime
 ./isprime

output:
7
5
Output
12
Input 
59
2
Output
61
Input 
9
2
Output
9 is not prime number 
Input 
9
12
Output
9 is not prime number 
12 is not prime number


