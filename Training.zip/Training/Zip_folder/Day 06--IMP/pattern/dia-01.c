#include<stdio.h>
#include<stdlib.h>

int main(){ 
	printf("%.3f\n",1.123456f);
	printf("%.*f\n",3,1.123456f);
	printf("%.3s\n","Arjun");
	printf("%.*s\n",3,"Arjun");
}	