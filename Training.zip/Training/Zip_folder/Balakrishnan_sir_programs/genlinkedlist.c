#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node
{
    void *data;
    struct node *next;
};
struct linkedlist
{
    struct node *head;
    int count;
};

void linkedlist_init(struct linkedlist *lst)
{
    lst->head = NULL;
    lst->count = 0;
}

void linkedlist_addHead(struct linkedlist *lst, void *val, unsigned int size)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->data = malloc(size);
    memcpy(newNode->data, val, size);
    newNode->next = lst->head;
    lst->head = newNode;
    lst->count++;
}

void linkedlist_print(struct linkedlist *lst, void (*print_value)(void *))
{
    struct node *curr = lst->head;
    while (curr != NULL)
    {
        print_value(curr->data);
        curr = curr->next;
    }
}

void linkedlist_delete(struct linkedlist *lst)
{

    struct node *curr = lst->head;
    while (curr != NULL)
    {
        struct node *temp = curr;
        curr = curr->next;
        free(temp->data);
        free(temp);
    }
}

void *linkedlist_getAt(struct linkedlist *lst, int pos)
{
    if (pos < 0 || pos >= lst->count)
    {
        return NULL;
    }
    struct node *curr = lst->head;
    for (int i = 0; i < pos; i++)
    {
        curr = curr->next;
    }
    return curr->data;
}
void print_int(void *val)
{
    int *intVal = (int *)val;
    printf("\t%d\n", *intVal);
}
void print_double(void *val)
{
    double *dVal = (double *)val;
    printf("\t%lg\n", *dVal);
}
struct product
{
    int code, stock;
    char name[64];
    double price;
};
void print_product(void *val)
{
    struct product *pVal = (struct product *)val;
    printf("\tcode: %d, name: %s, price: %.2lg, stock: %d\n", pVal->code, pVal->name, pVal->price, pVal->stock);
}

int main()
{
    struct linkedlist lst1;
    linkedlist_init(&lst1);
    int a[10] = {3, 2, 5, 7, 9, 12, 4, 1, 23, 67};

    for (int i = 0; i < 10; i++)
    {
        linkedlist_addHead(&lst1, &a[i], sizeof(int));
    }
    linkedlist_print(&lst1, print_int);
    linkedlist_delete(&lst1);

    printf("---------------------------------------------\n");
    struct linkedlist lst2;
    linkedlist_init(&lst2);
    double d[10] = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0};

    for (int i = 0; i < 10; i++)
    {
        linkedlist_addHead(&lst2, &d[i], sizeof(double));
    }
    linkedlist_print(&lst2, print_double);
    linkedlist_delete(&lst2);

    printf("---------------------------------------------\n");
    struct linkedlist lst3;
    linkedlist_init(&lst3);
    struct product p[3] = {
        {1, 25, "milk", 45.5},
        {2, 35, "Fruits", 50.5},
        {9, 45, "dry fruits", 65.55}};

    for (int i = 0; i < 3; i++)
    {
        linkedlist_addHead(&lst3, &p[i], sizeof(struct product));
    }
    linkedlist_print(&lst3, print_product);
    printf("---------------------------------------------\n");

    void *prod = linkedlist_getAt(&lst3, 0);
    print_product(prod);
    printf("---------------------------------------------\n");

    prod = linkedlist_getAt(&lst3, 1);
    print_product(prod);
    printf("---------------------------------------------\n");

    prod = linkedlist_getAt(&lst3, 2);
    print_product(prod);

    return 0;
}