#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node
{
    void *data;
    struct node *next;
};
struct linkedlist
{
    struct node *head;
    int count;
};

void linkedlist_init(struct linkedlist *lst)
{
    lst->head = NULL;
    lst->count = 0;
}

void linkedlist_addHead(struct linkedlist *lst, void *val, unsigned int size)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->data = malloc(size);
    memcpy(newNode->data, val, size);
    newNode->next = lst->head;
    lst->head = newNode;
    lst->count++;
}

void linkedlist_print(struct linkedlist *lst, void (*print_value)(void *))
{
    struct node *curr = lst->head;
    while (curr != NULL)
    {
        print_value(curr->data);
        curr = curr->next;
    }
}

/*void linkedlist_delete(struct linkedlist *lst)
{

    struct node *curr = lst->head;
    while (curr != NULL)
    {
        struct node *temp = curr;
        curr = curr->next;
        free(temp->data);
        free(temp);
    }
}
*/

void linkedlist_delete(struct linkedlist *lst, void (*delete_object)(void *))
{

    struct node *curr = lst->head;
    while (curr != NULL)
    {
        struct node *temp = curr;
        curr = curr->next;
        delete_object(temp->data);
        free(temp);
    }
}
void *linkedlist_getAt(struct linkedlist *lst, int pos)
{
    if (pos < 0 || pos >= lst->count)
    {
        return NULL;
    }
    struct node *curr = lst->head;
    for (int i = 0; i < pos; i++)
    {
        curr = curr->next;
    }
    return curr->data;
}
struct product
{
    int code, stock;
    char *name;
    double price;
} __attribute__((__packed__));

/*struct product
{
    int code;
    char *category;
    double price;
    int stock;
    char *name;

}__attribute__((__packed__));*/

void print_product(void *val)
{
    struct product *pVal = (struct product *)val;
    printf("\tcode: %d, name: %s, price: %.2lg, stock: %d\n", pVal->code, pVal->name, pVal->price, pVal->stock);
}

void delete_product(void *val)
{
    struct product *pVal = (struct product *)val;
    free(pVal->name);
}

int main()
{
    printf("size of product = %lu\n", sizeof(struct product));
    struct linkedlist lst3;
    linkedlist_init(&lst3);
    struct product p[3] = {
        {1, 25, "milk", 45.5},
        {2, 35, "Fruits", 50.5},
        {9, 45, "dry fruits", 65.55}};

    struct product pr;
    pr.code = 6;
    pr.stock = 19;
    pr.price = 99.99;
    char *name = "Dark Chocklate";
    pr.name = (char *)malloc(strlen(name) + 1);
    strcpy(pr.name, name);

   /* for (int i = 0; i < 3; i++)
    {
        linkedlist_addHead(&lst3, &p[i], sizeof(struct product));
    }*/
    linkedlist_addHead(&lst3, &pr, sizeof(struct product));

    linkedlist_print(&lst3, print_product);
    //free(pr.name);
    printf("---------------------------------------------\n");
    linkedlist_delete(&lst3,delete_product);
    
    return 0;
}