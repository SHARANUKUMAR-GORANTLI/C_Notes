#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct int_array
{
	int count, capacity;
	int *data;
};

void int_array_init(struct int_array *array)
{
	array -> count = 0;
	array -> capacity = 2;
	array -> data = (int*)malloc(array -> capacity * (sizeof(int)));
}
void int_array_delete(struct int_array *array)
{
	free(array -> data);
	array -> data = NULL;
}

void int_array_add(struct int_array *array, int val)
{
	if(array -> count >= array -> capacity)
	{
		array -> capacity *= 2;
		array -> data = (int*)realloc(array -> data, array -> capacity * sizeof(int));	
	}
	array -> data[array -> count++] = val;
}

void int_array_print(struct int_array *array)
{
	for(int i = 0;i < array -> count; i++)
	{
		printf("\t%d\n",array -> data[i]);
	}
}

void int_array_copy(struct int_array *dest, struct int_array *source)
{
	free(dest -> data);
	*dest = *source;
	dest -> data = (int*)malloc(dest -> capacity * sizeof(int));
	memcpy(dest -> data, source -> data, source -> count *sizeof(int));
}

int main()
{
	/*struct int_array a1, a2;
	int_array_init(&a1);
	int_array_init(&a2);
	for(int i = 1;i < 11;i++)
	{
		int_array_add(&a1, i*i);
		int_array_add(&a2, i*i*i);
	}
	int_array_print(&a1);
	int_array_delete(&a1);
	int_array_print(&a2);
	int_array_delete(&a2);*/
	
	struct int_array a1, a2;
	int_array_init(&a1);
	int_array_init(&a2);
	int_array_add(&a1, 10);
	int_array_add(&a1, 20);
	printf("Array1 printing...\n");
	int_array_print(&a1);
	int_array_copy(&a2, &a1);
	printf("Array2 printing...\n");
	int_array_print(&a2);
	printf("Array1 deleting...\n");
	int_array_delete(&a1);
	printf("Array2 deleting...\n");
	int_array_delete(&a2);
	
	return EXIT_SUCCESS;
}
