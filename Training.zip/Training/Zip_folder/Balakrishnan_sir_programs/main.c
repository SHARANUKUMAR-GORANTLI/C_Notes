#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "product.h"
int main()
{
    char opt = 'A';
    while (opt!='q')
    {

        printf("\n\n\n\tEnter p to add product, s to do sales or q to quit: ");
        (void)scanf("%c", &opt);
        switch (opt)
        {
        case 'p':
            manageProducts();
            break;

        case 's':
            break;
        default :
            printf("\n\tInvalid Option; enter p, s or q");
            break;
        case 'q':
            return 0;
        }
    }
    return 0;
}