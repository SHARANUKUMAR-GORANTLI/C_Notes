//Dynamic array   //Refactoring code
#include<stdio.h>
#include<stdlib.h>
void add_to_array(int **pdata, int *pcount, int *pcapacity, int num)
{
	if((*pcount) >= (*pcapacity))  // count==capacity means array is full
		{
			(*pcapacity) *= 2;      
			int *temp = (int*)malloc((*pcapacity) * sizeof(int));  
			for(int i = 0; i < (*pcount) ; i++) 
			{
				temp[i] = (*pdata)[i];
			}
			free(*pdata);   //free up old array memory
		    *pdata = temp;  //store new arrray's reference in variable data.
		}
		(*pdata)[(*pcount)++] = num;
}
void add_to_array2(int **pdata, int *pcount, int *pcapacity, int num)
{
	if((*pcount) >= (*pcapacity))  // count==capacity means array is full
		{
			(*pcapacity) *= 2;      
			*pdata = (int*)realloc(*pdata,(*pcapacity) * sizeof(int));  
		}
		(*pdata)[(*pcount)++] = num;
}
int main()
{
	int count = 0, capacity = 2, max = 10;
	int *data;
	//data = (int*)malloc(capacity * sizeof(int));
	data = (int*)calloc(capacity , sizeof(int));
	int num;
	while(count < max)
	{
		printf("Enter new number: ");
		scanf("%d", &num);
		add_to_array2(&data, &count, &capacity, num);
		
		printf("\n\n\n\n");
		for(int i = 0; i < count ; i++)
		{
			printf("\t%d\n", data[i]);
		}
		printf("\n\n\n\n");
	} //end -- while(count < max)
	free(data);
	return EXIT_SUCCESS;
}




