#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void print(const int *const ptr)
{
    printf("%d\n", *ptr);
    //*ptr = 20;
    // ptr = (int  *)malloc(4);
}

struct product
{
    int code, stock;
    char name[64];
    double price;
};

void print_product(const struct product *pVal)
{
    printf("\tcode: %d, name: %s, price: %.2lg, stock: %d\n", pVal->code, pVal->name, pVal->price, pVal->stock);
    if(pVal->price == 100.0)
    {

        printf("price is rs 100\n");
    }

}
int main()
{
    int x = 10, y = 20;
    const int a = x;
    // a = y;               // a can not be modified.
    const int *b = &x;
    printf("value at b =%d\n", *b);
    b = &y;

    printf("value at b =%d\n", *b);
    //*b = x;          //address in b can be changed (new address can be stored in b)
    // but can not use b to derefrence and modify value.
    const int *const c = &x;
    // c = &y;        //address stored in c can not be chnaged.
    //*c = y;           //c can not be defereced to modify the value at that reference.

    printf("value at c =%d\n", *c);

    return 0;
}