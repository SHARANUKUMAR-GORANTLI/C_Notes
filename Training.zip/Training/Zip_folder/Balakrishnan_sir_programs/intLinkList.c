#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct int_node
{
	int val;
	struct int_node* next;
};

struct int_linked_list
{
	struct int_node* head;
};

void int_linked_list_init(struct int_linked_list *list)
{
	list -> head = NULL;
}

void int_linked_list_add(struct int_linked_list *list, int num)
{
	struct int_node* newNode = (struct int_node*) malloc(sizeof(struct int_node));
	newNode -> val = num;
	newNode -> next = NULL;
	if(list -> head == NULL)
	{
		list -> head = newNode;
		return;
	}
	struct int_node *current = list -> head;
	while(current -> next != NULL)
	{
		current = current -> next;
	}	
	current -> next = newNode;	
}

void int_linked_list_addHead(struct int_linked_list *list, int num)
{
	struct int_node* newNode = (struct int_node*) malloc(sizeof(struct int_node));
	newNode -> val = num;
	newNode -> next = list -> head;
	list -> head = newNode;	
}

void int_linked_list_print(struct int_linked_list *list)
{
	if(list -> head == NULL)
	{
		printf("List is empty!!!\n");
		return;
	}
	struct int_node *current = list -> head;
	while(current != NULL)
	{
		printf("\t%d\n",current -> val);
		current = current -> next;
	}		
}

void int_linked_list_delete(struct int_linked_list *list)
{
	if(list -> head == NULL)
	{
		return;
	}
	struct int_node *current = list -> head;
	while(current != NULL)
	{
		struct int_node* temp = current;
		current = current -> next;
		free(temp);
	}		
}

int main()
{
	struct int_linked_list a1, a2;
	int_linked_list_init(&a1);
	int_linked_list_init(&a2);
	for(int i = 1;i < 11;i++)
	{
		int_linked_list_addHead(&a1, i*i);
		int_linked_list_addHead(&a2, i*i*i);
	}
	int_linked_list_print(&a1);
	int_linked_list_delete(&a1);
	int_linked_list_print(&a2);
	int_linked_list_delete(&a2);
	
	return EXIT_SUCCESS;

}
