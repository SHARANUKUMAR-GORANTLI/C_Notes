struct product
{
    int code;
    int stock;
    char name[32];
    double price;

};

void addProduct(struct product* p);
void displayProduct(struct product* p); //single product
void displayProducts(struct product* p, int size); //(list of product) for array of product we need size also to distinguish
void manageProducts();