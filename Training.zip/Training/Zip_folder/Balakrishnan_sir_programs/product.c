#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "product.h"
static struct product products[10];
static volatile int count = 0; // No optimiztion based on value of count

void addProduct(struct product *p)
{
    printf("\n\n\tAdding new product\n\n");
    printf("\tEnter code : ");
    (void)scanf("%d", &p->code);
    printf("\tEnter name : ");
    (void)scanf("%s", p->name);
    printf("\tEnter price : ");
    (void)scanf("%lg", &p->price);
    printf("\tEnter stock value : ");
    (void)scanf("%d", &p->stock);
    products[count] = *p;
    printf("\n\tDone\n");
}
void displayProduct(struct product *p) // single product
{
    printf("Code: %d, Name: %s, Price: %lg, Stock: %d\n", p->code, p->name, p->price, p->stock);
}
void displayProducts(struct product *p, int size) //(list of product) for array of product we need size also to distinguish
{
    int i;
    for (i = 0; i < size; i++)
    {
        displayProduct(p + i); // displayProduct(&p[i]);  //or
    }
}
void manageProducts()
{
    char ch;

    while (count < 10)
    {
        printf("\n\n\n\tA to add, P to print, Q to Quit. Enter choice: ");
        (void)scanf(" %c", &ch);

        switch (ch)
        {
        case 'q':
        case 'Q':
            return;
        case 'p':
        case 'P':
            printf("\n\n\n");
            displayProducts(products, count);
            break;
        case 'a':
        case 'A':
            printf("\n\n\n");
            addProduct(&products[count]);
            count++;
            break;
        default:
            printf("\n\n\tHuh?");
        }
    }
    printf("\n\n\n\tProduct store is full.\n");
}