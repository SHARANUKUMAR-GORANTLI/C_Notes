#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    void *ptr = malloc(0);
    printf("%lu\n", (unsigned long)ptr);
    free(ptr);

    void *ptr2 = NULL;
    printf("%lu\n", (unsigned long)ptr2);
    free(ptr2);

    return 0;
}