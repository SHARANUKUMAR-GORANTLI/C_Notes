#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char* filename = "./def.info";

struct product
{
  int code, stock;
  char name[32];
  double price;
};

//format- 00000000050000000025orange        0000000055.00
char* ptemp = "Code: %d, name: %s, price: %.2lf, stock: %d\n";

void rtrim(char* str)
{
  int len = strlen(str);
  while(str[--len] == ' ')
  {
    
  }
  str[len + 1] = '\0'; 
}
void parseProduct(char* str, struct product* p)
{
  char codeStr[11], stockStr[11], name[32], priceStr[14];
  memcpy(codeStr, str, 10);
  codeStr[10] = '\0';
  p->code = atoi(codeStr);
  str += 10;
  memcpy(stockStr, str, 10);
  stockStr[10] = '\0';
  p->stock = atoi(stockStr);
  str += 10;
  memcpy(name, str, 30);
  name[30] = '\0';
  str += 30;
  strcpy(p->name, name);
  rtrim(p->name);
  memcpy(priceStr, str, 13);
  priceStr[13] = '\0';
  p->price = atof(priceStr);
}

int main()
{ 
  FILE* fp = fopen(filename, "r");//create: typedef struct _iobuff FILE
  char buff[100];
  while(fgets(buff, 99, fp) != NULL)
  {
    struct product p;
    parseProduct(buff, &p);
    printf(ptemp, p.code, p.name, p.price, p.stock);
  }
  fclose(fp);
  
  return 0; 
}
//00000000120000000120                Nagpur Oranges0000000090.50
 
