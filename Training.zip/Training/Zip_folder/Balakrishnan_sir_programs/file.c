#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char* filename = "./abc.txt";

int main()
{
  typedef int bool;
  bool b = 1;
  /*FILE* fp = fopen(filename, "w");//create: typedef struct _iobuff FILE
  fprintf( fp, "Good Morning\n");
  fflush(fp);
  fclose(fp);*/
  FILE* fp = fopen(filename, "r");//create: typedef struct _iobuff FILE
  char str[256];
  //fscanf(fp, "%s", str);
  char* retVal = fgets(str, 255, fp);
  if(retVal != NULL)
  {
    printf("\t%s\n",str);
  }
  fclose(fp);
  
  return 0; 
}

 
