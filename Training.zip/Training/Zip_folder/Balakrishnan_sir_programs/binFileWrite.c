#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char* filename = "./ghi.bd";

struct product
{
  int code, stock;
  char name[32];
  double price;
};

int main()
{
  struct product p1 = {12, 120, "Nagpur Oranges", 90.5};
  struct product p2 = {14, 125, "Shimla Apples", 100};
  struct product p3 = {16, 127, "Aasam Tea", 200.75};
  struct product p4 = {18, 129, "Coorg Coffee", 150.25};
  
  FILE* fp = fopen(filename, "ab");//create: typedef struct _iobuff FILE
  fwrite(&p1, sizeof(struct product), 1, fp);
  fwrite(&p2, sizeof(struct product), 1, fp);
  fwrite(&p3, sizeof(struct product), 1, fp);
  fwrite(&p4, sizeof(struct product), 1, fp);
  fflush(fp);
  fclose(fp);
  
  return 0; 
}
//00000000120000000120                Nagpur Oranges0000000090.50
 
