#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char* filename = "./def.info";

struct product
{
  int code, stock;
  char name[32];
  double price;
};

//format- 00000000050000000025orange        0000000055.00
char* ptemp = "%010d%010d%-30s%013.2lf\n";


int main()
{
  struct product p1 = {12, 120, "Nagpur Oranges", 90.5};
  struct product p2 = {14, 125, "Shimla Apples", 100};
  struct product p3 = {16, 127, "Aasam Tea", 200.75};
  struct product p4 = {18, 129, "Coorg Coffee", 150.25};
  //printf(ptemp, p.code, p.stock, p.name, p.price);
  
  FILE* fp = fopen(filename, "a");//create: typedef struct _iobuff FILE
  fprintf(fp, ptemp, p1.code, p1.stock, p1.name, p1.price);
  fprintf(fp, ptemp, p2.code, p2.stock, p2.name, p2.price);
  fprintf(fp, ptemp, p3.code, p3.stock, p3.name, p3.price);
  fprintf(fp, ptemp, p4.code, p4.stock, p4.name, p4.price);
  fclose(fp);
  
  return 0; 
}
//00000000120000000120                Nagpur Oranges0000000090.50
 
