#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char* filename = "./ghi.bd";

char* ptemp = "Code: %d, name: %s, price: %.2lf, stock: %d\n";

struct product
{
  int code, stock;
  char name[32];
  double price;
};

int main()
{ 
  FILE* fp = fopen(filename, "rb");//create: typedef struct _iobuff FILE
  while(1)
  {
    struct product p;
    //void* buff = (void*) &p;
    fread(&p, sizeof(struct product), 1, fp); //for array we use here  n * sizeof(struct product) or pass n in 3rd param
    if(feof(fp)) 
    {
      break;
    }
    printf(ptemp, p.code, p.name, p.price, p.stock);
  }
  fclose(fp);
  
  return 0; 
}
//00000000120000000120                Nagpur Oranges0000000090.50
 
