#include<stdio.h>
#include<stdlib.h>

struct _node_t{
    double data;
    struct _node_t* next;
};

typedef struct _node_t node_t;
	
void traversal(node_t *head);
void pop_front(node_t **headAddr);
void node_init(node_t* node, double val){

    node->data = val;
    node->next = NULL;
}
	

void push_front(node_t **headAddr, double val){

    node_t *head = (*headAddr);
    node_t* node = (node_t*)malloc(1*sizeof(node_t));
	
    node_init(node,val);//{50,x}
    
    node_t* temp = head;
   //adjust
   if(head == NULL){
        //empty list
        node->next = node;
        head = node;
    }else{
	
        //list of atleast one node
	      while(temp->next != head)
	      {
	          temp = temp->next;
	      }
	      temp->next = node;
        node->next = head;
        
        head = node;
    }
	
    (*headAddr) = head;
}

void pop_front(node_t **headAddr){

    node_t *head = (*headAddr);

    if(head == NULL){

        printf("List is empty.\n");

        return;
    }

    node_t* node = head;
	  node_t* temp = head;
    //adjust	

    if(node->next == node){

        head = NULL;	

    }else{	
        while(temp->next != head)
        {
            temp = temp->next;
        }
        temp->next = head->next;
        head = node->next;	

    }
	
    //deallocator	

    node->next = NULL;

    free(node);

    node = NULL;	
	
    (*headAddr) = head;
	
}
	
double front(node_t *head){
	
    if(head == NULL){
	
        printf("List is empty.\n");
	
        return -1.0;
    }
	
    return head->data;

}

void traversal(node_t *head){	

    node_t* node = head;
    
    if(head == NULL)
	  {
	      printf("List is empty.\n");
	      return;
    }
	
    printf("The salaries are:\n");
	
	  do
    {
        printf("%.2lf ",node->data);
	
        node = node->next;
    }while(node != head);
	
    printf("\n");
}
	 

void destroy(node_t **headAddr){
	
    node_t *head = (*headAddr);
	
	  if(head == NULL)
	  {
	      return;
    }
	  node_t *node = head;
    do
    {
        printf("%.2lf is deleted.\n",front(node));
        pop_front(&node);
        
    }while(node != NULL);

    (*headAddr) = head;
	
}
	

int main(){
	
    node_t *head = NULL; 
    int menu;

    do{
        printf("Pick Choice\n");	
        printf("\t1-Add Front, 2-Delete Front\n");
        printf("\t3-Traversal\n");
        //printf("\tRecursion next 4-Traversal Forward, 5-Traversal Backward\n");
        printf("\t0-Exit\n");
        printf("Your Choice:"); scanf("%d",&menu);
        
        if(1 == menu){
	
            double salary = 0.0;
	
            printf("Enter data:"); scanf("%lf",&salary);	

            push_front(&head, salary);
	
        }else if(2 == menu){
	
            if(head == NULL){	

                printf("List is empty.\n");

            }else{

                double salary = front(head);

                pop_front(&head);
	
                printf("%.2lf is Deleted.\n",salary);
	
            }
	
        }else if(3 == menu){
	
            traversal(head);

        }else{
	
            printf("Application is shutting down....\n");   
	
        }
	
    }while((1 <= menu) && (menu <= 3));
	
    destroy(&head);	

    return EXIT_SUCCESS;
	
}

 
