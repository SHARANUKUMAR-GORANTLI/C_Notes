#include<stdio.h>
#include<stdlib.h>

struct _node_t{
    double data;
    struct _node_t* next;
    struct _node_t* prev;
};

typedef struct _node_t node_t;
	
void traversal(node_t *head);
void pop_front(node_t **headAddr, node_t **tailAddr);
void pop_back(node_t **tailAddr, node_t **headAddr);
void node_init(node_t* node, double val){

    node->data = val;
    node->next = NULL;
    node->prev = NULL;
}
	

void push_front(node_t **headAddr, node_t **tailAddr, double val){

    node_t *head = (*headAddr);
    node_t *tail = (*tailAddr);
    node_t* node = (node_t*)malloc(1*sizeof(node_t));
	
    node_init(node,val);//{50,x}
   //adjust
    
    node_t* temp = head;
    
    if(head == NULL){
        //empty list
        node->next = node;
        node->prev = node;
        head = node;
        tail = node;
    }else{
	
        //list of atleast one node
	      while(temp->next != head)
	      {
	          temp = temp->next;
	      }
	      temp->next = node;
	      node->prev = temp;
        node->next = head;
        head->prev = node;
        
        head = node;
    }
	
    (*headAddr) = head;
    (*tailAddr) = tail;
}

void pop_front(node_t **headAddr, node_t **tailAddr){

    node_t *head = (*headAddr);
    node_t *tail = (*tailAddr);
    
    if(head == NULL){

        printf("List is empty.\n");

        return;
    }

    node_t* node = head;
	  node_t* temp = head;
    //adjust	

    if(node->next == node){

        head = NULL;	
        tail = NULL;

    }else{	
        while(temp->next != head)
        {
            temp = temp->next;
        }
        temp->next = head->next;
        head->next->prev = temp;
        head = node->next;	

    }
	
    //deallocator	

    node->next = NULL;

    free(node);

    node = NULL;	
	
    (*headAddr) = head;
    (*tailAddr) = tail;
	
}
	
double front(node_t *head){
	
    if(head == NULL){
	
        printf("List is empty.\n");
	
        return -1.0;
    }
	
    return head->data;

}

void push_back(node_t **tailAddr, node_t **headAddr, double val){

    node_t *tail = (*tailAddr);
    node_t *head = (*headAddr);
    node_t* node = (node_t*)malloc(1*sizeof(node_t));
	
    node_init(node,val);//{50,x}
    //adjust
    node_t* temp = tail;
    
    if(tail == NULL){
        //empty list
        node->next = node;
        node->prev = node;
        head = node;
        tail = node;
    }else{
	
        //list of atleast one node
	      while(temp->prev != tail)
	      {
	          temp = temp->prev;
	      }
	      temp->prev = node;
	      node->next = temp;
        node->prev = tail;
        tail->next = node;
        
        tail = node;
    }
    
	
    (*tailAddr) = tail;
    (*headAddr) = head;
}

void pop_back(node_t **tailAddr, node_t **headAddr){

    node_t *tail = (*tailAddr);
    node_t *head = (*headAddr);
    
    if(head == NULL){

        printf("List is empty.\n");

        return;
    }

    node_t* node = tail;
	  node_t* temp = tail;
    //adjust	

    if(node->next == node){

        head = NULL;	
        tail = NULL;

    }else{	
        while(temp->prev != tail)
        {
            temp = temp->prev;
        }
        temp->prev = tail->prev;
        tail->prev->next = temp;
        tail = node->prev;	

    }
	
    //deallocator	

    node->prev = NULL;

    free(node);

    node = NULL;	
	
    (*tailAddr) = tail;
    (*headAddr) = head;
	
}
	
double back(node_t *tail){
	
    if(tail == NULL){
	
        printf("List is empty.\n");
	
        return -1.0;
    }
	
    return tail->data;

}

void destroy(node_t **headAddr, node_t **tailAddr){
	
    node_t *head = (*headAddr);
    node_t *tail = (*tailAddr);
	

    while(head != NULL){
	
        printf("%.2lf is deleted.\n",front(head));
	
        pop_front(&head, &tail);
    }	
    head = NULL;
    tail = NULL;

    (*headAddr) = head;
    (*tailAddr) = tail;
	
}

void traversal_forward(node_t *head){
    
    node_t* node = head;
    
    if(head == NULL)
	  {
	      printf("List is empty.\n");
	      return;
    }
	
    printf("The salaries are:\n");
	
	  do
    {
        printf("%.2lf ",node->data);
	
        node = node->next;
    }while(node != head);
	
    printf("\n");
}
void traversal_backward(node_t *tail){
    node_t* node = tail;
    
    if(tail == NULL)
	  {
	      printf("List is empty.\n");
	      return;
    }
	
    printf("The salaries are:\n");
	
	  do
    {
        printf("%.2lf ",node->data);
	
        node = node->prev;
    }while(node != tail);
	
    printf("\n");
}

	

int main(){  
	
    node_t *head = NULL;
    node_t *tail = NULL;
    int menu;

    do{
        printf("Pick Choice\n");
        printf("\t1-Add Front, 2-Delete Front\n");
        printf("\t3-Add Back, 4-Delete Back\n");
        printf("\t5-Traversal Forward,6-Traversal Backward\n");
        printf("\t0-Exit\n");
        printf("Your Choice:"); scanf("%d",&menu);
        
        if(1 == menu){
            double salary = 0.0;
            printf("Enter data:"); scanf("%lf",&salary);
            push_front(&head, &tail, salary);
        }else if(2 == menu){
            if(head == NULL){
                printf("List is empty.\n");
            }else{
                double salary = front(head);
                pop_front(&head, &tail);
                printf("%.2lf is Deleted.\n",salary);
            }
        }else if(3 == menu){
            double salary = 0.0;
            printf("Enter data:"); scanf("%lf",&salary);
            push_back(&tail, &head, salary);
        }else if(4 == menu){
            if(tail == NULL){  //CODE CHANGED HERE Vishal
                printf("List is empty.\n");
            }else{
                double salary = back(tail);
                pop_back(&tail, &head);
                printf("%.2lf is Deleted.\n",salary);
            }
        }else if(5 == menu){
            traversal_forward(head);
        }else if(6 == menu){
            traversal_backward(tail);
        }else{
            printf("Application is shutting down....\n");    
        }
    }while((1 <= menu) && (menu <= 10));
	
    destroy(&head, &tail);	

    return EXIT_SUCCESS;
	
}

 
