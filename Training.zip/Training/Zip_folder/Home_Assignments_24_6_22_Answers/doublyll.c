#include<stdio.h>
#include<stdlib.h>

struct _node_t{
    double data;
    struct _node_t* next;
    struct _node_t* prev;
};

typedef struct _node_t node_t;
	
void traversal(node_t *head);
void pop_front(node_t **headAddr, node_t **tailAddr);
void pop_back(node_t **tailAddr, node_t **headAddr);
void node_init(node_t* node, double val){

    node->data = val;
    node->next = NULL;
    node->prev = NULL;
}
	

void push_front(node_t **headAddr, node_t **tailAddr, double val){

    node_t *head = (*headAddr);
    node_t *tail = (*tailAddr);
    node_t* node = (node_t*)malloc(1*sizeof(node_t));
	
    node_init(node,val);//{50,x}
   //adjust
   if(head == NULL){
        //empty list
        head = node;
        tail = node;
    }else{
	
        //list of atleast one node
	
        node->next = head;
        head->prev = node;
        head = node;
    }
	
    (*headAddr) = head;
    (*tailAddr) = tail;
}

void pop_front(node_t **headAddr, node_t **tailAddr){

    node_t *head = (*headAddr);
    node_t *tail = (*tailAddr);

    if(head == NULL){

        printf("List is empty.\n");

        return;
    }

    node_t* node = head;
	
    //adjust	

    if(head->next != NULL){
        head->next->prev = NULL;
        head = head->next;
        //head = NULL;	

    }else{	
        head = NULL;
        tail = NULL;	

    }
	
    //deallocator	

    node->next = NULL;

    free(node);

    node = NULL;	
	
    (*headAddr) = head;
    (*tailAddr) = tail;
	
}
	
double front(node_t *head){
	
    if(head == NULL){
	
        printf("List is empty.\n");
	
        return -1.0;
    }
	
    return head->data;

}

void push_back(node_t **tailAddr, node_t **headAddr, double val){

    node_t *tail = (*tailAddr);
    node_t *head = (*headAddr);
    node_t* node = (node_t*)malloc(1*sizeof(node_t));
	
    node_init(node,val);//{50,x}
   //adjust
   if(tail == NULL){
        //empty list
        tail = node;
        head = node;
    }else{
	
        //list of atleast one node
	
        node->prev = tail;
        tail->next = node;
        tail = node;
    }
	
    (*tailAddr) = tail;
    (*headAddr) = head;
}

void pop_back(node_t **tailAddr, node_t **headAddr){

    node_t *tail = (*tailAddr);
    node_t *head = (*headAddr);

    if(tail == NULL){

        printf("List is empty.\n");

        return;
    }

    node_t* node = tail;
	
    //adjust	

    if(tail->prev != NULL){
        tail->prev->next = NULL;
        tail = tail->prev;
        //tail = NULL;	

    }else{	
        tail = NULL;	
        head = NULL;

    }
	
    //deallocator	

    node->prev = NULL;

    free(node);

    node = NULL;	
	
    (*tailAddr) = tail;
    (*headAddr) = head;
	
}
	
double back(node_t *tail){
	
    if(tail == NULL){
	
        printf("List is empty.\n");
	
        return -1.0;
    }
	
    return tail->data;

}

void destroy(node_t **headAddr, node_t **tailAddr){
	
    node_t *head = (*headAddr);
    node_t *tail = (*tailAddr);
	

    while(head != NULL){
	
        printf("%.2lf is deleted.\n",front(head));
	
        pop_front(&head, &tail);
    }	
    head = NULL;
    tail = NULL;

    (*headAddr) = head;
    (*tailAddr) = tail;
	
}

void traversal_forward(node_t *head){
    node_t* node = head;
    printf("The salaries are:\n");
    while(node != NULL){
        printf("%.2lf ->",node->data);
        node = node->next;
    }
    printf("\n");
}
void traversal_backward(node_t *tail){
    node_t* node = tail;
    printf("The reverse of salaries are:\n");
    while(node != NULL){
        printf("%.2lf ->",node->data);
        node = node->prev;
    }
    printf("\n");
}
void traversal_next_recursion_forward(node_t* nodeAddr){
    if(nodeAddr == NULL){
        return;
    }
    printf("%.2lf ->",nodeAddr->data);
    traversal_next_recursion_forward(nodeAddr->next);
}

void traversal_next_recursion_backward(node_t* nodeAddr){
    if(nodeAddr == NULL){
        return;
    }
    
    traversal_next_recursion_backward(nodeAddr->next);
    printf("%.2lf ->",nodeAddr->data);
}
void traversal_prev_recursion_backward(node_t* nodeAddr){
    if(nodeAddr == NULL){
        return;
    }
    printf("%.2lf ->",nodeAddr->data);
    traversal_prev_recursion_backward(nodeAddr->prev);
}

void traversal_prev_recursion_forward(node_t* nodeAddr){
    if(nodeAddr == NULL){
        return;
    }
    
    traversal_prev_recursion_forward(nodeAddr->prev);
    printf("%.2lf ->",nodeAddr->data);
}
	

int main(){  
	
    node_t *head = NULL;
    node_t *tail = NULL;
    int menu;

    do{
        printf("Pick Choice\n");
        printf("\t1-Add Front, 2-Delete Front\n");
        printf("\t3-Add Back, 4-Delete Back\n");
        printf("\t5-Traversal Forward,6-Traversal Backward\n");
        printf("\tRecursion next 7-Traversal Forward, 8-Traversal Backward\n");
        printf("\tRecursion prev 9-Traversal Forward, 10-Traversal Backward\n");
        printf("\t0-Exit\n");
        printf("Your Choice:"); scanf("%d",&menu);
        
        if(1 == menu){
            double salary = 0.0;
            printf("Enter data:"); scanf("%lf",&salary);
            push_front(&head, &tail, salary);
        }else if(2 == menu){
            if(head == NULL){
                printf("List is empty.\n");
            }else{
                double salary = front(head);
                pop_front(&head, &tail);
                printf("%.2lf is Deleted.\n",salary);
            }
        }else if(3 == menu){
            double salary = 0.0;
            printf("Enter data:"); scanf("%lf",&salary);
            push_back(&tail, &head, salary);
        }else if(4 == menu){
            if(tail == NULL){  //CODE CHANGED HERE Vishal
                printf("List is empty.\n");
            }else{
                double salary = back(tail);
                pop_back(&tail, &head);
                printf("%.2lf is Deleted.\n",salary);
            }
        }else if(5 == menu){
            traversal_forward(head);
        }else if(6 == menu){
            traversal_backward(tail);
        }else if(7 == menu){
            printf("The salaries are:\n");
            traversal_next_recursion_forward(head);
            printf("\n");
        }else if(8 == menu){
            printf("The reverse of the salaries are:\n");
            traversal_next_recursion_backward(head);
            printf("\n");
        }else if(9 == menu){
            printf("The salaries are:\n");
            traversal_prev_recursion_forward(tail);
            printf("\n");
        }else if(10 == menu){
            printf("The reverse of the salaries are:\n");
            traversal_prev_recursion_backward(tail);
            printf("\n");
        }else{
            printf("Application is shutting down....\n");    
        }
    }while((1 <= menu) && (menu <= 10));
	
    destroy(&head, &tail);	

    return EXIT_SUCCESS;
	
}

 
