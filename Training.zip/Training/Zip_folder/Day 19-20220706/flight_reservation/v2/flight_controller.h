#pragma once
#include"flight_db.h"
#include"flight_ui.h"
void action_product_show_all();
void action_product_create();
