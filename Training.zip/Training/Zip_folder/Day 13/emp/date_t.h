#pragma once
struct _date_t{
	int day;
	int month;
	int year;
};
typedef struct _date_t date_t;