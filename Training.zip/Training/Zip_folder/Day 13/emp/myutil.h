#pragma once
void clear_input_buffer(void);