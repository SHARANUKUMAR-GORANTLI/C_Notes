#include<stdio.h>
#include<string.h>

union measure
{
	int number;
	float litre;
	double gram;
};

struct product
{
	int code;
	char name[151];
	double price;
	union measure stock;
	char uom;
};

void show(struct product *p);
void show_products(struct product p[], int n);
void read(struct product *p);
int search(char *txt, struct product p[], int size);
int search_name(char *name, struct product *p);

struct product products[10];
int count = 0;

int main()
{
	char ch;

	while(count<10)
	{
		printf("\n\n\n\tA to add, P to print, S to search, Q to Quit. Enter choice: ");
		scanf(" %c", &ch);	
		
		switch(ch)
		{
			case 'q':
			case 'Q':
				return 0;
			case 'p':
			case 'P':
				printf("\n\n\n");
				/*for(int i=0;i<count;i++)
				{
					show(products[i]);
				}*/
				show_products(products, count);
				break;
			case 'a':
			case 'A':
				printf("\n\n\n");
				read(&products[count]);
				count++;
				break;
			case 's':
			case 'S':
				printf("\n\n\n");
				struct product p;
				char txt[150];
				printf("Enter name to search: ");
				scanf("%s", txt);
				
				int res = search_name(txt, &p);
				if(res)
				{
					printf("\n\n\n");
					show(&p);
					printf("\n\n\n");
				}
				else
				{
					printf("'%s' not found", txt);
				}
				break;
			default:
				printf("\n\n\tHuh?");
		}
	}

	return 0;
}

void show(struct product *p)
{
	printf("\tCode : %d, Name : '%s', Price : %lg, Stock : ", p->code, p->name, p->price);
	switch(p->uom)
	{
		case 'N':
		case 'n':
			printf("%d nos", p->stock.number);
			break;
		case 'G':
		case 'g':
			printf("%lg gms", p->stock.gram);
			break;
		case 'L':
		case 'l':
			printf("%lg ltr", p->stock.litre);
			break;
		default:
			printf("Unknown");
	}
	printf("\n");
}

void read(struct product *p)
{
	printf("\tEnter code : ");
	scanf("%d", &p->code);
	printf("\tEnter name : ");
	scanf("%s", p->name);
	printf("\tEnter price : ");
	scanf("%lg", &p->price);
	printf("\tEnter unit of measure (N/G/L) : ");
	scanf(" %c", &p->uom);
	printf("\tEnter stock value : ");
	switch(p->uom)
	{
		case 'n':
		case 'N':
			scanf("%d", &p->stock.number);
			break;
		case 'g':
		case 'G':
			scanf("%lg", &p->stock.gram);
			break;
		case 'l':
		case 'L':
			scanf("%g", &p->stock.litre);
			break;
	}

	return;
}

void show_products(struct product p[], int n)
{
	for(int i=0;i<n;i++)
	{
		show(&p[i]);
		//show(p+i);
	}
}

int search_name(char *name, struct product *p)
{
	for(int i=0;i<count;i++)
	{
		int r = strcmp(products[i].name, name);
		if(r==0)
		{
			p->code = products[i].code;
			strcpy(p->name, products[i].name);
			p->price = products[i].price;
			p->uom = products[i].uom;
			p->stock = products[i].stock;
			
			return 1;
		}
	}

	return 0;
}
